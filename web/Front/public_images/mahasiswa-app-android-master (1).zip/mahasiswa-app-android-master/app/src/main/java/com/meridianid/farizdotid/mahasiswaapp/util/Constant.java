package com.meridianid.farizdotid.mahasiswaapp.util;

/**
 * Created by fariz ramadhan.
 * website : www.farizdotid.com
 * github : https://github.com/farizdotid
 * linkedin : https://www.linkedin.com/in/farizramadhan/
 */


public class Constant {
    public static final String KEY_ID_MATKUL = "keyIdMatkul";
    public static final String KEY_NAMA_DOSEN = "keyNamaDosen";
    public static final String KEY_MATKUL = "keyMatkul";
}
