package xyz.hasnat.demoapi.Constants;

public class Constant {

    /** Constants values are here */
    public static class baseUrl{
        public final static String BASE_URL = "PUT-YOUR-BASE-URL-HERE";
        public final static String IMAGE_BASE_URL = "";
    }


}
