Rest-posts
=========

A Symfony Api to manage Posts.
